import sys, os, re
sys.path.insert(0,'.')
from mkword import render

FONT = '/home/claude/fonts/ibm-plex-sans/fonts/complete/ttf/IBMPlexSans-SemiBold.ttf'
TEXT, SIZE, TRACK = 'tephpy', 30, -0.9
X0, BASE = 76.0, 42.0

COLD_L, COLD_D, EMBER = '#1B3A6B', '#8FB8E8', '#E4572E'
BG_L,  BG_D = '#FFFFFF', '#20242b'

# ---- tier artwork (curve clipped to circle: overshoot fixed) -------------
def tier_a(cold, ember, bg, uid):
    return f'''<defs><clipPath id="c{uid}"><circle cx="32" cy="32" r="27"/></clipPath></defs>
  <g clip-path="url(#c{uid})">
    <g stroke="{cold}" stroke-width="2.4" stroke-linecap="round" opacity="0.30">
      <path d="M-2 14 L50 66"/><path d="M12 0 L64 52"/><path d="M26 -14 L78 38"/>
      <path d="M66 14 L14 66"/><path d="M52 0 L0 52"/><path d="M38 -14 L-14 38"/>
    </g>
    <path d="M12 55 L30 30" fill="none" stroke="{cold}" stroke-width="6" stroke-linecap="round"/>
    <path d="M30 30 C36 21 40 15 52 9" fill="none" stroke="{ember}" stroke-width="6" stroke-linecap="round"/>
    <circle cx="30" cy="30" r="6.8" fill="{bg}"/>
    <circle cx="30" cy="30" r="4.6" fill="{ember}"/>
  </g>'''

def tier_b(cold, ember, bg, uid):
    return f'''<defs><clipPath id="c{uid}"><circle cx="32" cy="32" r="27"/></clipPath></defs>
  <g clip-path="url(#c{uid})">
    <g stroke="{cold}" stroke-width="3.4" stroke-linecap="round" opacity="0.34">
      <path d="M6 6 L58 58"/><path d="M58 6 L6 58"/>
    </g>
    <path d="M12 55 L30 30" fill="none" stroke="{cold}" stroke-width="7" stroke-linecap="round"/>
    <path d="M30 30 C36 21 40 15 52 9" fill="none" stroke="{ember}" stroke-width="7" stroke-linecap="round"/>
    <circle cx="30" cy="30" r="6.4" fill="{bg}"/>
    <circle cx="30" cy="30" r="4.2" fill="{ember}"/>
  </g>'''

def tier_c(cold, ember, bg, uid):
    return f'''<path d="M11 57 L30 30" fill="none" stroke="{cold}" stroke-width="9" stroke-linecap="round"/>
  <path d="M30 30 C36.5 20 41 14 53 8" fill="none" stroke="{ember}" stroke-width="9" stroke-linecap="round"/>'''

TIERS = {'a': tier_a, 'b': tier_b, 'c': tier_c}

def icon_svg(tier, cold, ember, bg, uid):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" '
            f'width="64" height="64" role="img" aria-label="tephpy">\n'
            f'  <title>tephpy</title>\n  {TIERS[tier](cold, ember, bg, uid)}\n</svg>\n')

def lockup_svg(tier, cold, ember, bg, uid, mono=False):
    colorfn = (lambda i: 'currentColor') if mono else (lambda i: cold if i < 4 else ember)
    paths, adv = render(FONT, TEXT, SIZE, TRACK, colorfn, X0, BASE)
    W = int(X0 + adv + 12)
    art = TIERS[tier](cold, ember, bg, uid)
    ca = ' color="#1B3A6B"' if mono else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} 64" '
            f'width="{W}" height="64" role="img" aria-label="tephpy"{ca}>\n'
            f'  <title>tephpy</title>\n  {art}\n  <g>\n    {paths}\n  </g>\n</svg>\n')

os.makedirs('bundle/svg', exist_ok=True)
made = []
for theme, cold, bg in [('light', COLD_L, BG_L), ('dark', COLD_D, BG_D)]:
    for tier in ('a','b','c'):
        uid = f'{tier}{theme}'
        p = f'bundle/svg/icon-tier{tier}-{theme}.svg'
        open(p,'w').write(icon_svg(tier, cold, EMBER, bg, uid)); made.append(p)
        p = f'bundle/svg/lockup-tier{tier}-{theme}.svg'
        open(p,'w').write(lockup_svg(tier, cold, EMBER, bg, uid+'L')); made.append(p)

# monochrome currentColor pair (tier A grid + tier C simplified)
for tier in ('a','c'):
    p = f'bundle/svg/lockup-tier{tier}-mono.svg'
    open(p,'w').write(lockup_svg(tier, 'currentColor', 'currentColor', BG_L, tier+'M', mono=True))
    made.append(p)
    p = f'bundle/svg/icon-tier{tier}-mono.svg'
    open(p,'w').write(icon_svg(tier, 'currentColor', 'currentColor', BG_L, tier+'MI'))
    made.append(p)

print(f"{len(made)} SVGs written")
for m in made: print("  ", m)

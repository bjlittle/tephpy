from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen

def word_paths(fontpath, text, size, tracking=0.0):
    """Return (list of (char, pathdata, xoffset)), total advance, in em-scaled units."""
    f = TTFont(fontpath)
    upem = f['head'].unitsPerEm
    gs = f.getGlyphSet()
    cmap = f.getBestCmap()
    hmtx = f['hmtx']
    scale = size / upem
    out = []
    x = 0.0
    for ch in text:
        gname = cmap[ord(ch)]
        pen = SVGPathPen(gs)
        gs[gname].draw(pen)
        d = pen.getCommands()
        adv = hmtx[gname][0] * scale
        out.append((ch, d, x, scale))
        x += adv + tracking
    return out, x

def render(fontpath, text, size, tracking, colors, x0, baseline):
    """colors: dict char-index-range -> fill. Returns svg group string."""
    glyphs, total = word_paths(fontpath, text, size, tracking)
    parts = []
    for i,(ch, d, xo, scale) in enumerate(glyphs):
        if not d: 
            continue
        fill = colors(i)
        parts.append(
          f'<path d="{d}" fill="{fill}" transform="translate({x0+xo:.3f} {baseline:.3f}) scale({scale:.6f} {-scale:.6f})"/>'
        )
    return "\n    ".join(parts), total

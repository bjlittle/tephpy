import sys; sys.path.insert(0,'.')
from mkword import render

FONT='/home/claude/fonts/ibm-plex-sans/fonts/complete/ttf/IBMPlexSans-SemiBold.ttf'
TEXT,SIZE,TRACK,X0,BASE='tephpy',30,-0.9,76.0,42.0

# Mono tier A: grid + curve, no halo. Node drawn as a solid dot only; the
# curve is split so it doesn't run under the dot.
MONO_A = '''<defs><clipPath id="cm{u}"><circle cx="32" cy="32" r="27"/></clipPath></defs>
  <g clip-path="url(#cm{u})">
    <g stroke="currentColor" stroke-width="2.4" stroke-linecap="round" opacity="0.28">
      <path d="M-2 14 L50 66"/><path d="M12 0 L64 52"/><path d="M26 -14 L78 38"/>
      <path d="M66 14 L14 66"/><path d="M52 0 L0 52"/><path d="M38 -14 L-14 38"/>
    </g>
    <path d="M12 55 L30 30 C36 21 40 15 52 9" fill="none" stroke="currentColor"
          stroke-width="6" stroke-linecap="round"/>
  </g>'''

MONO_C = '''<path d="M11 57 L30 30 C36.5 20 41 14 53 8" fill="none"
        stroke="currentColor" stroke-width="9" stroke-linecap="round"/>'''

def icon(body,u):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" '
            f'height="64" role="img" aria-label="tephpy" color="#1B3A6B">\n  <title>tephpy</title>\n  '
            + body.format(u=u) + '\n</svg>\n')

def lockup(body,u):
    paths,adv = render(FONT,TEXT,SIZE,TRACK,lambda i:'currentColor',X0,BASE)
    W=int(X0+adv+12)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} 64" width="{W}" '
            f'height="64" role="img" aria-label="tephpy" color="#1B3A6B">\n  <title>tephpy</title>\n  '
            + body.format(u=u) + f'\n  <g>\n    {paths}\n  </g>\n</svg>\n')

open('bundle/svg/icon-tiera-mono.svg','w').write(icon(MONO_A,'ai'))
open('bundle/svg/icon-tierc-mono.svg','w').write(icon(MONO_C,'ci'))
open('bundle/svg/lockup-tiera-mono.svg','w').write(lockup(MONO_A,'al'))
open('bundle/svg/lockup-tierc-mono.svg','w').write(lockup(MONO_C,'cl'))
print('mono rebuilt')

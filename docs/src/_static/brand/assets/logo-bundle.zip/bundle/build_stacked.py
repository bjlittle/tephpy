import sys, os
sys.path.insert(0,'.')
from mkword import render, word_paths

FONT='/home/claude/fonts/ibm-plex-sans/fonts/complete/ttf/IBMPlexSans-SemiBold.ttf'
TEXT='tephpy'
SIZE=17
TRACK=-0.9*SIZE/30          # scale tracking proportionally

COLD_L, COLD_D, EMBER = '#1B3A6B', '#8FB8E8', '#E4572E'
BG_L, BG_D = '#FFFFFF', '#20242b'

# Canvas: 64 wide, icon occupies y 0..64, wordmark below with a 6u gap.
# Cap height at 17px is ~12.6u, descender ~3.4u -> baseline at 64+6+12.6 = 82.6
GAP = 6.0
BASELINE = 64 + GAP + 12.6
CANVAS_H = int(BASELINE + 4.5 + 3)   # descender + bottom margin

def tier_a(cold, ember, bg, uid):
    return f'''<defs><clipPath id="c{uid}"><circle cx="32" cy="32" r="27"/></clipPath></defs>
  <g clip-path="url(#c{uid})">
    <g stroke="{cold}" stroke-width="2.4" stroke-linecap="round" opacity="0.30">
      <path d="M-2 14 L50 66"/><path d="M12 0 L64 52"/><path d="M26 -14 L78 38"/>
      <path d="M66 14 L14 66"/><path d="M52 0 L0 52"/><path d="M38 -14 L-14 38"/>
    </g>
    <path d="M12 55 L30 30" fill="none" stroke="{cold}" stroke-width="6" stroke-linecap="round"/>
    <path d="M30 30 C36 21 40 15 52 9" fill="none" stroke="{ember}" stroke-width="6" stroke-linecap="round"/>
    <circle cx="30" cy="30" r="6.8" fill="{bg}"/>
    <circle cx="30" cy="30" r="4.6" fill="{ember}"/>
  </g>'''

def tier_b(cold, ember, bg, uid):
    return f'''<defs><clipPath id="c{uid}"><circle cx="32" cy="32" r="27"/></clipPath></defs>
  <g clip-path="url(#c{uid})">
    <g stroke="{cold}" stroke-width="3.4" stroke-linecap="round" opacity="0.34">
      <path d="M6 6 L58 58"/><path d="M58 6 L6 58"/>
    </g>
    <path d="M12 55 L30 30" fill="none" stroke="{cold}" stroke-width="7" stroke-linecap="round"/>
    <path d="M30 30 C36 21 40 15 52 9" fill="none" stroke="{ember}" stroke-width="7" stroke-linecap="round"/>
    <circle cx="30" cy="30" r="6.4" fill="{bg}"/>
    <circle cx="30" cy="30" r="4.2" fill="{ember}"/>
  </g>'''

def tier_c(cold, ember, bg, uid):
    return f'''<path d="M11 57 L30 30" fill="none" stroke="{cold}" stroke-width="9" stroke-linecap="round"/>
  <path d="M30 30 C36.5 20 41 14 53 8" fill="none" stroke="{ember}" stroke-width="9" stroke-linecap="round"/>'''

# mono tiers: no halo, single continuous curve
def tier_a_mono(uid):
    return f'''<defs><clipPath id="c{uid}"><circle cx="32" cy="32" r="27"/></clipPath></defs>
  <g clip-path="url(#c{uid})">
    <g stroke="currentColor" stroke-width="2.4" stroke-linecap="round" opacity="0.28">
      <path d="M-2 14 L50 66"/><path d="M12 0 L64 52"/><path d="M26 -14 L78 38"/>
      <path d="M66 14 L14 66"/><path d="M52 0 L0 52"/><path d="M38 -14 L-14 38"/>
    </g>
    <path d="M12 55 L30 30 C36 21 40 15 52 9" fill="none" stroke="currentColor"
          stroke-width="6" stroke-linecap="round"/>
  </g>'''

def tier_c_mono(uid):
    return '''<path d="M11 57 L30 30 C36.5 20 41 14 53 8" fill="none"
        stroke="currentColor" stroke-width="9" stroke-linecap="round"/>'''

TIERS = {'a': tier_a, 'b': tier_b, 'c': tier_c}
MONO  = {'a': tier_a_mono, 'c': tier_c_mono}

def stacked(art, cold, ember, mono=False):
    colorfn = (lambda i: 'currentColor') if mono else (lambda i: cold if i < 4 else ember)
    _, adv = word_paths(FONT, TEXT, SIZE, TRACK)
    x0 = 32.0 - adv/2.0 - 0.35               # optical correction: measured ink centre, not advance width
    paths, _ = render(FONT, TEXT, SIZE, TRACK, colorfn, x0, BASELINE)
    ca = ' color="#1B3A6B"' if mono else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 {CANVAS_H}" '
            f'width="64" height="{CANVAS_H}" role="img" aria-label="tephpy"{ca}>\n'
            f'  <title>tephpy</title>\n  {art}\n  <g>\n    {paths}\n  </g>\n</svg>\n')

os.makedirs('bundle/svg', exist_ok=True)
made=[]
for theme, cold, bg in [('light',COLD_L,BG_L), ('dark',COLD_D,BG_D)]:
    for t in ('a','b','c'):
        uid=f'st{t}{theme}'
        p=f'bundle/svg/stacked-tier{t}-{theme}.svg'
        open(p,'w').write(stacked(TIERS[t](cold,EMBER,bg,uid), cold, EMBER)); made.append(p)
for t in ('a','c'):
    p=f'bundle/svg/stacked-tier{t}-mono.svg'
    open(p,'w').write(stacked(MONO[t]('stm'+t), 'currentColor','currentColor', mono=True)); made.append(p)

print(f"canvas 64x{CANVAS_H}, type {SIZE}px, baseline {BASELINE}")
print(f"{len(made)} stacked SVGs")
for m in made: print("  ",m)

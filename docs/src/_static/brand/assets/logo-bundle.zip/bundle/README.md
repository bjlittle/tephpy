# tephpy logo bundle

Complete asset set built from the v2 grid mark: the parcel path (dry adiabat →
LCL → moist adiabat) over a ±45° tephigram lattice.

Palette — indigo `#1B3A6B` (dry adiabat), ember `#E4572E` (moist adiabat), sky
`#8FB8E8` (dark-theme substitution for indigo).

Type — IBM Plex Sans SemiBold, 30px, tracking `-0.9`, converted to outline
paths. No `<text>` element and no webfont dependency: every file renders
identically regardless of installed fonts. Licence is SIL OFL 1.1, so vendoring
the outlined paths in a BSD-3 project is fine.

## Layout

```
bundle/
├── svg/        24 vector files — icon, horizontal & stacked lockup,
│                 3 tiers, light/dark/mono
├── png/        22 raster files — icon & both lockups, light/dark, @1x–@8x
└── favicon/    ICO, PNG set, theme-aware SVG, webmanifest
```

Two lockup orientations are provided: **horizontal** (179×64, wordmark to the
right of the icon) and **stacked** (64×90, wordmark centred beneath). Use
horizontal for docs headers and README banners where vertical space is tight;
stacked for square-ish contexts — social avatars, conference slides, sticker
sheets, anywhere the mark sits in a column.

## The three tiers

The lattice is the first element to break as size drops, so the mark exists in
three drawings rather than one. Pick by rendered size, not by purpose.

| Tier | Use at | Grid | LCL node | Stroke |
|---|---|---|---|---|
| **A** | 48px and above | Six lines, 2.4u @ 30% | Yes, haloed | 6u |
| **B** | 24–32px | Two diagonals, 3.4u @ 34% | Yes, tight halo | 7u |
| **C** | 20px and below | None | None | 9u |

At 16px the tier-A grid strokes fall below one device pixel and resolve to grey
mush behind the curve — hence tier C drops them outright rather than scaling
them down. Tier B exists because the full lattice is still muddy at 32px, but
the mark can afford *some* grid.

In all tiers the parcel path is clipped to the same `r=27` circle as the
lattice. This resolves the overshoot present in the earlier
`v2-grid-icon-light.svg`, where the curve ran past the grid at both ends.

## SVG — `svg/`

| File | viewBox | Notes |
|---|---|---|
| `icon-tier{a,b,c}-light.svg` | 64×64 | Indigo + ember on light |
| `icon-tier{a,b,c}-dark.svg` | 64×64 | Sky + ember on dark |
| `lockup-tier{a,b,c}-light.svg` | 179×64 | Icon + wordmark, light |
| `lockup-tier{a,b,c}-dark.svg` | 179×64 | Icon + wordmark, dark |
| `stacked-tier{a,b,c}-light.svg` | 64×90 | Wordmark beneath icon, light |
| `stacked-tier{a,b,c}-dark.svg` | 64×90 | Wordmark beneath icon, dark |
| `icon-tier{a,c}-mono.svg` | 64×64 | Single `currentColor` |
| `lockup-tier{a,c}-mono.svg` | 179×64 | Single `currentColor` |
| `stacked-tier{a,c}-mono.svg` | 64×90 | Single `currentColor` |

In the **horizontal** lockups the wordmark sits at `x=76`, baseline `y=42`,
spanning y=19.8–48.0 on a 64-unit canvas — optically centred against the mark.
The `teph`/`py` colour split falls at the fourth glyph.

The **stacked** lockups use 17px type rather than 30px, with tracking scaled
proportionally to `-0.51`. That size was chosen by measurement, not by eye: the
tier-A icon's visible ink is 51.5u wide (narrower than its 64u canvas), and
17px type gives a 52.0u wordmark — a 0.5u difference, so the two elements read
as the same width. 18px would overshoot by 3.7u and make the wordmark visibly
wider than the mark above it.

Horizontal centring is corrected by −0.35u against the glyph advance width,
because advance width includes side bearings and is not the same as visible
ink. Measured result: icon ink centre 31.95u, wordmark ink centre 32.00u.
Baseline sits at y=82.6 — a 6u gap below the 64u icon, plus the 12.6u cap
height.

**The mono files are the only ones that are truly background-independent.**
They carry no background-coloured fills, inherit `color` from the page, and
have been verified against arbitrary backgrounds (cream, dark green) as well as
plain light and dark. Tiers B has no mono variant — its halo requires a
background colour; use tier A or C.

## PNG — `png/`

Icons at 64/128/256/512, horizontal lockups at 179/358/716 (@1x/@2x/@4x of the
native 179×64), stacked lockups at 64/128/256/512 wide (aspect-correct against
the native 64×90), each in light and dark.

⚠️ **The dark PNGs have a baked-in halo.** The ring around the LCL node is
filled `#20242b` and the background is transparent, so these files only look
right composited on a dark background near that value. On a light or mid-tone
background the halo appears as a dark blob. If you need a dark-stroke mark on
an unknown background, use `lockup-tiera-mono.svg` and set `color` instead.

## Favicons — `favicon/`

| File | Size | Tier | Notes |
|---|---|---|---|
| `favicon.ico` | 16/32/48 | C/B/A | Multi-resolution, genuine per-tier art |
| `favicon.svg` | vector | C | Theme-aware via `prefers-color-scheme` |
| `favicon-16x16.png` | 16 | C | |
| `favicon-32x32.png` | 32 | B | |
| `favicon-48x48.png` | 48 | A | |
| `apple-touch-icon.png` | 180 | A | Opaque white bg — iOS ignores alpha |

`favicon.svg` uses tier-C artwork (no grid) because browsers render it at
16–32px. It therefore will not match the full grid mark in your docs header.
That is the right trade-off for a tab icon; if you want a lattice-carrying SVG
for other uses, take `svg/icon-tiera-light.svg`.

## Verification

Every claim below was checked, not assumed:

- All 24 SVGs parse as valid XML.
- Zero files contain a live `<text>` element — type is fully outlined.
- Zero mono files contain hardcoded `#FFFFFF` or `#20242b`.
- No duplicate `clipPath` ids across the bundle. This matters: inlining two
  SVGs with colliding ids into one HTML page silently breaks clipping on one of
  them.
- `favicon.ico` parses as type 1 with three genuine entries (16/32/48, 32bpp),
  and each embedded frame pixel-diffs to 0.00 against its standalone PNG —
  confirming real per-tier art rather than downscales of a single source. Worth
  re-running after any build change: PIL's `append_images` silently drops or
  resamples frames in some versions.

## Usage

### GitHub README / HTML

```html
<picture>
  <source srcset="bundle/svg/lockup-tiera-dark.svg"
          media="(prefers-color-scheme: dark)">
  <img src="bundle/svg/lockup-tiera-light.svg" alt="tephpy" width="179">
</picture>
```

For the stacked variant, swap the filenames and set `width="64"`:

```html
<picture>
  <source srcset="bundle/svg/stacked-tiera-dark.svg"
          media="(prefers-color-scheme: dark)">
  <img src="bundle/svg/stacked-tiera-light.svg" alt="tephpy" width="64">
</picture>
```

### Sphinx (pydata-sphinx-theme, furo)

```python
html_theme_options = {
    "logo": {
        "image_light": "_static/lockup-tiera-light.svg",
        "image_dark": "_static/lockup-tiera-dark.svg",
    }
}
html_favicon = "_static/favicon.ico"
html_static_path = ["_static"]
```

`html_favicon` accepts a single file, so the SVG and apple-touch variants need
a custom `layout.html` block.

### Site head

```html
<link rel="icon" href="/favicon.ico" sizes="32x32">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
```

### Monochrome

```html
<div style="color: #1B3A6B">
  <img src="bundle/svg/lockup-tiera-mono.svg" alt="tephpy" width="179">
</div>
```

Inline the SVG rather than using `<img>` if you need `currentColor` to actually
inherit — referenced images do not inherit the parent document's colour.

## Regenerating

`build_bundle.py` builds the icon and horizontal-lockup matrix;
`build_stacked.py` builds the stacked variants; `fix_mono.py` rebuilds the
horizontal mono files without background-dependent fills. All depend on
`mkword.py` for glyph-to-path conversion via fontTools. SVG paths are
machine-generated — change the wordmark by re-running the build, not by
hand-editing.

If you change the wordmark text, re-derive the stacked type size: measure the
icon's ink width, then pick the size whose advance width matches it. The
current 17px is specific to the string `tephpy`.

## Note on the Python logo

An earlier revision considered placing the PSF two-snake mark behind the icon.
That mark is a registered trademark of the Python Software Foundation, whose
policy restricts uses implying endorsement or affiliation; building it into a
package's own logo reads as official Python tooling. numpy, pandas, scipy and
MetPy all avoid it for the same reason. The lattice fills the same compositional
space using the project's own subject matter.
